let temperaturaActual = 20;
const COSTO_POR_GRADO = 0.15; // Euros al día (Ficticio para el cálculo)

const displayTemp = document.getElementById("temp-value");
const displayStatus = document.getElementById("status-text");
const displayCost = document.getElementById("energy-cost");
const barraEnergia = document.getElementById("energy-fill");
const panelTermostato = document.getElementById("thermostat-ui");
const listaDispositivos = document.getElementById("devices-list");

document
  .getElementById("btn-increase")
  .addEventListener("click", () => cambiarTemperatura(1));
document
  .getElementById("btn-decrease")
  .addEventListener("click", () => cambiarTemperatura(-1));

// Cargamos los datos al iniciar la página
document.addEventListener("DOMContentLoaded", cargarDatosJSON);

function cambiarTemperatura(cambio) {
  temperaturaActual += cambio;

  // 1. Actualizar número en pantalla
  displayTemp.textContent = temperaturaActual;

  // 2. Lógica de Colores y Estado (Feedback Visual)
  if (temperaturaActual < 18) {
    displayStatus.textContent = "Modo: Frío Eco";
    panelTermostato.style.borderColor = "var(--temp-cold)";
    barraEnergia.style.backgroundColor = "var(--temp-cold)";
  } else if (temperaturaActual > 24) {
    displayStatus.textContent = "Modo: Calefacción Alta";
    panelTermostato.style.borderColor = "var(--temp-hot)";
    barraEnergia.style.backgroundColor = "var(--temp-hot)";
  } else {
    displayStatus.textContent = "Modo: Confort";
    panelTermostato.style.borderColor = "var(--temp-eco)";
    barraEnergia.style.backgroundColor = "var(--temp-eco)";
  }

  // 3. RETO MATEMÁTICO ANTI-IA: Calcular coste dinámico
  calcularGasto(temperaturaActual);
}

function calcularGasto(temp) {
  // Fórmula simple: Temperatura base * factor de coste
  // Usamos Math.abs para evitar costes negativos si baja mucho
  const coste = (Math.abs(temp) * COSTO_POR_GRADO).toFixed(2);

  displayCost.textContent = coste;

  // Efecto visual en la barra de progreso (simulada)
  // Limitamos el ancho entre 0% y 100%
  const porcentaje = Math.min(Math.max((temp - 10) * 5, 10), 100);
  barraEnergia.style.width = `${porcentaje}%`;
}

// --- FUNCIÓN 2: AJAX/FETCH (Consumir JSON) ---
async function cargarDatosJSON() {
  try {
    const respuesta = await fetch("./data.json");
    if (!respuesta.ok) throw new Error("No se pudo cargar el JSON");
    const datos = await respuesta.json();

    listaDispositivos.innerHTML = ""; // Limpia el mensaje de carga

    datos.items.forEach((item) => {
      const estado = item.stock > 0 ? "Encendido" : "Apagado";
      const claseEstado = item.stock > 0 ? "text-success" : "text-muted";

      // AQUÍ ESTÁ EL CAMBIO: Añadimos la etiqueta <img>
      // Usamos item.imagen del JSON
      const tarjetaHTML = `
                <article class="device-card">
                    <img src="${item.imagen}" alt="${item.nombre}" class="card-img">
                    <div class="card-content">
                        <h3>${item.nombre}</h3>
                        <p>${item.descripcion}</p>
                        <div style="margin-top: 10px;">
                            <strong>Estado:</strong> <span class="${claseEstado}">${estado}</span> <br>
                            <strong>Consumo:</strong> ${item.precio} W
                        </div>
                        <span class="tag">${item.categoria}</span>
                    </div>
                </article>
            `;

      listaDispositivos.innerHTML += tarjetaHTML;
    });
  } catch (error) {
    console.error("Error:", error);
    listaDispositivos.innerHTML = `<p style="color:red">Error cargando dispositivos.</p>`;
  }
}
